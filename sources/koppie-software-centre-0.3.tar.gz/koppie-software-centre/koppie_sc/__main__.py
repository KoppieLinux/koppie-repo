import sys

from PyQt6.QtWidgets import QApplication

from .ui import MainWindow


def _set_wm_class(window, res_name, res_class):
    """Make the window's WM_CLASS match its .desktop StartupWMClass.

    Without this the window shows up as "__main__.py" and the desktop
    cannot match it to koppie-software-centre.desktop, so the taskbar
    shows a generic icon. Only works on the X11 (xcb) platform.
    """
    try:
        import ctypes

        class XClassHint(ctypes.Structure):
            _fields_ = [
                ("res_name", ctypes.c_char_p),
                ("res_class", ctypes.c_char_p),
            ]

        x11 = ctypes.CDLL("libX11.so.6")
        x11.XOpenDisplay.restype = ctypes.c_void_p
        x11.XSetClassHint.argtypes = [
            ctypes.c_void_p,
            ctypes.c_ulong,
            ctypes.POINTER(XClassHint),
        ]
        x11.XFlush.argtypes = [ctypes.c_void_p]

        display = x11.XOpenDisplay(None)
        if not display:
            return
        hint = XClassHint(res_name.encode(), res_class.encode())
        x11.XSetClassHint(display, int(window.winId()), ctypes.byref(hint))
        x11.XFlush(display)
    except Exception:
        pass


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Koppie Software Centre")
    app.setDesktopFileName("koppie-software-centre")
    window = MainWindow()
    window.show()
    if app.platformName() == "xcb":
        _set_wm_class(window, "koppie-software-centre", "koppie-software-centre")
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
