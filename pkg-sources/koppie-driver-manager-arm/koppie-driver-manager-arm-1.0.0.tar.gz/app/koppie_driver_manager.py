#!/usr/bin/env python3
"""
Koppie Driver Manager ARM (KDM-ARM)
Clean, user-friendly hardware driver utility for Koppie Linux on aarch64.

Dua target dukungan:
  * Apple Silicon (M1 - M5): stack driver mainline + Mesa Asahi + DSP audio Apple
  * Board aarch64 UEFI generik (Rockchip, Qualcomm, NXP, Broadcom, ...)

Versi ARM dari koppie-driver-manager (x86_64).
"""

import os
import re
import sys
import subprocess
import threading
from pathlib import Path
from PIL import Image

# Ensure bundled libraries are available
CURRENT_DIR = Path(__file__).resolve().parent
LIB_DIR = CURRENT_DIR / "lib"
if LIB_DIR.exists():
    sys.path.insert(0, str(LIB_DIR))

ASSETS_DIR = CURRENT_DIR / "assets"
LOGO_PATH = ASSETS_DIR / "koppie-logo.png"

import customtkinter as ctk
from tkinter import messagebox

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

# Koppie Clean Color Palette
BG_DARK = "#1a1b20"
CARD_BG = "#23252c"
CARD_HOVER = "#2d3039"
KOPPIE_CYAN = "#0cc1e0"
KOPPIE_CYAN_HOVER = "#00a8c6"
TEXT_PRIMARY = "#ffffff"
TEXT_SECONDARY = "#9ca3af"
SUCCESS_GREEN = "#10b981"
WARNING_AMBER = "#f59e0b"
INFO_BLUE = "#3b82f6"

DT_ROOT = Path("/proc/device-tree")

# Nama ramah untuk kode SoC Apple.
# Sumber: Asahi Linux documentation - SoC Codenames.
APPLE_SOC = {
    "t8103": "Apple M1",
    "t6000": "Apple M1 Pro",
    "t6001": "Apple M1 Max",
    "t6002": "Apple M1 Ultra",
    "t8112": "Apple M2",
    "t6020": "Apple M2 Pro",
    "t6021": "Apple M2 Max",
    "t6022": "Apple M2 Ultra",
    "t8122": "Apple M3",
    "t6030": "Apple M3 Pro",
    "t6031": "Apple M3 Max",
    "t6034": "Apple M3 Max",
    "t8132": "Apple M4",
    "t6040": "Apple M4 Pro",
    "t6041": "Apple M4 Max",
    "t8142": "Apple M5",
    "t6050": "Apple M5 Pro / Max",
}

# Modul driver nirkabel yang dikenal kernel
WIRELESS_DRIVERS = (
    "brcmfmac", "wl", "iwlwifi", "mt76", "mwifiex", "xr819",
    "ath11k", "ath10k", "ath9k", "ath5k", "rtw88", "rtw89", "rtl8xxxu",
)
# Potongan nama driver yang pasti nirkabel (dipakai buat nge-match sysfs)
WIRELESS_HINTS = ("brcm", "ath", "rtw", "iwl", "mt76", "mwifiex")


def _read_bytes(path):
    try:
        return Path(path).read_bytes()
    except Exception:
        return b""


def _read_text(path):
    try:
        return Path(path).read_text(errors="ignore").strip()
    except Exception:
        return ""


def _driver_of(link):
    """Nama driver dari symlink .../driver di sysfs."""
    try:
        p = Path(link)
        if p.exists() or p.is_symlink():
            return Path(os.readlink(p)).name
    except (OSError, ValueError):
        pass
    return ""


class HardwareScanner:
    # ------------------------------------------------------------------ info dasar
    @staticmethod
    def get_system_model():
        for p in (DT_ROOT / "model", Path("/sys/firmware/devicetree/base/model")):
            raw = _read_bytes(p)
            if raw:
                return raw.split(b"\x00")[0].decode("utf-8", "ignore").strip()
        vendor = _read_text("/sys/class/dmi/id/sys_vendor")
        product = _read_text("/sys/class/dmi/id/product_name")
        return f"{vendor} {product}".strip() or "Unknown computer"

    @staticmethod
    def get_kernel_version():
        return subprocess.getoutput("uname -r").strip()

    @staticmethod
    def get_arch():
        return subprocess.getoutput("uname -m").strip()

    @staticmethod
    def dt_compatible():
        raw = _read_bytes(DT_ROOT / "compatible")
        return [t.decode("utf-8", "ignore") for t in raw.split(b"\x00") if t]

    @staticmethod
    def is_apple_silicon():
        """True HANYA untuk Apple Silicon (M1-M5).

        Penanda yang sah adalah device-tree ("apple,t8103", dst). DMI product_name
        tidak dipakai: MacBook Intel juga menulis "Apple Inc." di situ, jadi
        kalau dipakai bakal false-positive di Mac lama.
        """
        if any(c.startswith("apple,") for c in HardwareScanner.dt_compatible()):
            return True
        # device-tree cuma ada di ARM. Kalau nggak ada, pasti bukan Apple Silicon.
        if not DT_ROOT.exists():
            return False
        return HardwareScanner.get_system_model().lower().startswith("apple")

    @staticmethod
    def get_soc():
        """Kembalikan (kode, nama_ramah) untuk SoC Apple, atau ("", "")."""
        for c in HardwareScanner.dt_compatible():
            m = re.match(r"apple,(t[0-9a-fA-F]+)", c)
            if m:
                code = m.group(1).lower()
                return code, APPLE_SOC.get(code, f"Apple SoC {code.upper()}")
        return "", ""

    # ------------------------------------------------------------------ paket
    @staticmethod
    def is_online(timeout=4):
        """Cek internet (buat download driver). True = nyambung."""
        import socket
        for host, port in (("1.1.1.1", 53), ("8.8.8.8", 53)):
            try:
                socket.create_connection((host, port), timeout=timeout).close()
                return True
            except OSError:
                continue
        return False

    @staticmethod
    def is_installed(pkg_name):
        res = subprocess.run(["pacman", "-Q", pkg_name],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return res.returncode == 0

    @staticmethod
    def pkg_available(pkg_name):
        """True kalau paket ada di repo yang terdaftar (core/extra/alarm/aur)."""
        res = subprocess.run(["pacman", "-Si", pkg_name],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return res.returncode == 0

    @staticmethod
    def headers_pkg():
        """Headers yang cocok dengan kernel yang sedang berjalan.

        Di aarch64 Arch Linux ARM cuma ada linux-aarch64-headers,
        jadi varian lain dicek dulu availability-nya se dipakai.
        """
        ver = subprocess.getoutput("uname -r").strip().lower()
        if "lts" in ver:
            wanted = "linux-aarch64-lts-headers"
        elif "zen" in ver:
            wanted = "linux-aarch64-zen-headers"
        else:
            wanted = "linux-aarch64-headers"
        if not HardwareScanner.pkg_available(wanted):
            return "linux-aarch64-headers"
        return wanted

    # ------------------------------------------------------------------ deteksi sysfs
    @staticmethod
    def drm_drivers():
        """{card0: 'apple', card1: 'panthor', ...}"""
        res = {}
        base = Path("/sys/class/drm")
        if not base.exists():
            return res
        for card in sorted(base.glob("card[0-9]*")):
            name = _driver_of(card / "device" / "driver")
            if name:
                res[card.name] = name
        return res

    @staticmethod
    def net_drivers():
        """{wlan0: 'brcmfmac', eth0: 'mvpp2', ...}"""
        res = {}
        base = Path("/sys/class/net")
        if not base.exists():
            return res
        for iface in sorted(base.glob("*")):
            if iface.name == "lo":
                continue
            res[iface.name] = _driver_of(iface / "device" / "driver")
        return res

    @staticmethod
    def wireless_driver():
        for _iface, drv in HardwareScanner.net_drivers().items():
            if not drv:
                continue
            if drv in WIRELESS_DRIVERS or any(h in drv for h in WIRELESS_HINTS):
                return drv
        for mod in WIRELESS_DRIVERS:
            if Path(f"/sys/module/{mod}").exists():
                return mod
        return ""

    @staticmethod
    def pci_devices():
        """Parse `lspci -nnk` (untuk board aarch64 UEFI yang punya PCIe)."""
        out = subprocess.getoutput("lspci -nnk")
        blocks, cur = [], []
        for line in out.splitlines():
            if line and not line[0].isspace():
                if cur:
                    blocks.append("\n".join(cur))
                cur = [line]
            elif line.strip():
                cur.append(line)
        if cur:
            blocks.append("\n".join(cur))

        devices = []
        for block in blocks:
            lines = [l.strip() for l in block.split("\n") if l.strip()]
            if not lines:
                continue
            header = lines[0]
            driver_in_use, subsystem = "", ""
            for line in lines[1:]:
                if line.startswith("Kernel driver in use:"):
                    driver_in_use = line.split(":", 1)[1].strip()
                elif line.startswith("Subsystem:"):
                    subsystem = line.split(":", 1)[1].strip()
            devices.append({
                "header": header,
                "lower": header.lower(),
                "driver": driver_in_use,
                "subsystem": subsystem,
            })
        return devices

    # ------------------------------------------------------------------ kartu device
    @classmethod
    def detect_devices(cls):
        devices = []
        apple = cls.is_apple_silicon()
        soc_code, soc_name = cls.get_soc()
        headers_pkg = cls.headers_pkg()

        # ---------------------------------------------------------- 1. Graphics / GPU
        drm = cls.drm_drivers()
        drm_names = list(drm.values())
        apple_gpu = apple and (
            any("apple" in n for n in drm_names) or Path("/sys/module/apple").exists()
        )

        if apple:
            mesa_ok = cls.is_installed("mesa")
            vulkan_ok = cls.is_installed("vulkan-asahi")
            driver_label = next((n for n in drm_names if "apple" in n), "apple")

            options = []
            if not mesa_ok and cls.pkg_available("mesa"):
                options.append({
                    "id": "mesa",
                    "title": "Mesa (OpenGL untuk GPU Apple)",
                    "desc": "Renderer 3D open-source untuk GPU Apple (driver asahi).",
                    "packages": ["mesa"],
                    "installed": False,
                })
            if not vulkan_ok and cls.pkg_available("vulkan-asahi"):
                options.append({
                    "id": "vulkan-asahi",
                    "title": "Vulkan Asahi (Vulkan untuk GPU Apple)",
                    "desc": "Implementasi Vulkan untuk GPU Apple, dibutuhkan game & aplikasi 3D.",
                    "packages": ["vulkan-asahi"],
                    "installed": False,
                })

            dev = {
                "category": "Graphics Adapter (GPU)",
                "name": f"Apple GPU ({soc_name or 'Apple Silicon'})",
                "subsystem": soc_name,
                "driver": driver_label,
                "type": "gpu",
                "options": options,
                "selected_option": 0,
                "packages_needed": [],
                "status_text": (
                    "Using in-kernel Apple DRM driver with Mesa Asahi "
                    "(OpenGL / Vulkan hardware acceleration)."
                    if mesa_ok else
                    "GPU terdeteksi, tapi Mesa belum terpasang."
                ),
            }
            if options:
                dev["packages_needed"] = [p for o in options for p in o["packages"]]
            devices.append(dev)

        else:
            # Board aarch64 generik: driver DRM (panthor/panfrost/v3d/...) atau GPU diskrit via PCIe
            gpu_drv = next(
                (n for n in drm_names
                 if n in ("panthor", "panfrost", "v3d", "vc4", "lima", "etnaviv",
                          "msm", "tegra", "evdi")),
                ""
            )
            dev = {
                "category": "Graphics Adapter (GPU)",
                "name": next(
                    (d["header"].split(": ", 1)[-1] for d in cls.pci_devices()
                     if any(k in d["lower"] for k in
                            ("vga compatible", "3d controller", "display controller"))),
                    "Graphics controller"
                ),
                "subsystem": "",
                "driver": gpu_drv or "modesetting",
                "type": "gpu",
                "options": [],
                "selected_option": 0,
                "packages_needed": [],
                "status_text": (
                    f"Using open-source {gpu_drv} driver with Mesa."
                    if gpu_drv else
                    "Using kernel modesetting driver."
                ),
            }

            # GPU diskrit (NVIDIA/AMD/Intel) lewat PCIe
            for d in cls.pci_devices():
                if not any(k in d["lower"] for k in
                           ("vga compatible", "3d controller", "display controller")):
                    continue
                if "nvidia" in d["lower"] or "10de:" in d["lower"]:
                    is_nv = cls.is_installed("nvidia-open-dkms") or cls.is_installed("nvidia-dkms")
                    nv_opts = []
                    if cls.pkg_available("nvidia-open-dkms"):
                        nv_opts.append({
                            "id": "nvidia",
                            "title": "NVIDIA Proprietary Driver (DKMS)",
                            "desc": "Driver resmi NVIDIA dengan akselerasi hardware & Vulkan.",
                            "packages": [headers_pkg, "nvidia-open-dkms"],
                            "installed": is_nv,
                        })
                    nv_opts.append({
                        "id": "nouveau",
                        "title": "Nouveau Open-Source Driver",
                        "desc": "Driver open-source bawaan kernel Linux.",
                        "packages": [],
                        "installed": not is_nv,
                    })
                    dev = {
                        "category": "Graphics Adapter (GPU)",
                        "name": d["header"].split(": ", 1)[-1] if ": " in d["header"] else d["header"],
                        "subsystem": d["subsystem"],
                        "driver": d["driver"] or "nouveau",
                        "type": "gpu",
                        "options": nv_opts,
                        "selected_option": 0 if is_nv else 1,
                        "packages_needed": [headers_pkg, "nvidia-open-dkms"]
                        if (not is_nv and cls.pkg_available("nvidia-open-dkms")) else [],
                        "status_text": "",
                    }
                elif "intel" in d["lower"] or "8086:" in d["lower"]:
                    dev["status_text"] = f"Using Intel Mesa driver ({d['driver'] or 'i915'}) with full 3D acceleration."
                elif "amd" in d["lower"] or "advanced micro devices" in d["lower"] or "1002:" in d["lower"]:
                    dev["status_text"] = f"Using AMD open-source driver ({d['driver'] or 'amdgpu'}) with Mesa."
            devices.append(dev)

        # ---------------------------------------------------------- 2. Wireless Network
        wl_drv = cls.wireless_driver()
        wl_pci = next(
            (d for d in cls.pci_devices()
             if "network controller" in d["lower"] or "wireless" in d["lower"]),
            None
        )
        if wl_drv or wl_pci:
            header = wl_pci["header"] if wl_pci else "Wireless network adapter"
            lower = (wl_pci["lower"] if wl_pci else wl_drv.lower())
            driver_in_use = wl_drv or (wl_pci["driver"] if wl_pci else "")

            dev = {
                "category": "Wireless Network",
                "name": header.split(": ", 1)[-1] if ": " in header else header,
                "subsystem": wl_pci["subsystem"] if wl_pci else "",
                "driver": driver_in_use or "None",
                "type": "wifi",
                "options": [],
                "selected_option": 0,
                "packages_needed": [],
            }

            if "broadcom" in lower or "brcm" in lower or "14e4:" in lower:
                fw_pkgs = [p for p in ("linux-firmware-broadcom", "linux-firmware")
                           if cls.pkg_available(p) and not cls.is_installed(p)]
                if fw_pkgs:
                    dev["options"] = [{
                        "id": "fw",
                        "title": "Firmware Broadcom/Cypress (linux-firmware)",
                        "desc": "Firmware Wi-Fi wajib supaya adapter Broadcom bisa jalan.",
                        "packages": fw_pkgs,
                        "installed": False,
                    }]
                    dev["packages_needed"] = fw_pkgs
                    dev["selected_option"] = 0
                else:
                    dev["status_text"] = "Using in-kernel brcmfmac driver with firmware installed."
            elif "intel" in lower or "8086:" in lower:
                dev["status_text"] = "Using open-source Intel driver (iwlwifi) provided by the Linux kernel."
            elif "realtek" in lower or "10ec:" in lower:
                dev["status_text"] = f"Using Realtek driver ({driver_in_use or 'rtw88'}) included in the kernel."
            else:
                dev["status_text"] = f"Using kernel driver: {driver_in_use or 'Generic open-source driver'}"

            devices.append(dev)

        # ---------------------------------------------------------- 3. Audio (khusus Apple Silicon)
        if apple:
            audio_missing = []
            for pkg in ("alsa-ucm-conf", "alsa-utils", "pipewire"):
                if cls.pkg_available(pkg) and not cls.is_installed(pkg):
                    audio_missing.append(pkg)

            dsp_pkg = cls.is_installed("speakersafetyd")
            dev = {
                "category": "Audio (Apple DSP)",
                "name": "Apple audio codec & DSP",
                "subsystem": soc_name,
                "driver": "snd-soc-* / asahi",
                "type": "audio",
                "options": [],
                "selected_option": 0,
                "packages_needed": [],
            }
            if audio_missing:
                dev["options"] = [{
                    "id": "audio",
                    "title": "Paket audio dasar (ALSA + PipeWire)",
                    "desc": "Profil UCM & server audio supaya speaker/headset jalan.",
                    "packages": audio_missing,
                    "installed": False,
                }]
                dev["packages_needed"] = audio_missing
            else:
                dev["status_text"] = (
                    "ALSA + PipeWire terpasang. Daemon DSP Apple (speakersafetyd) "
                    "belum ada di repo Arch Linux ARM."
                    if not dsp_pkg else
                    "ALSA + PipeWire + speakersafetyd terpasang."
                )
            devices.append(dev)

        # ---------------------------------------------------------- 4. Storage
        if Path("/sys/class/nvme").exists() or Path("/sys/class/scsi_disk").exists():
            devices.append({
                "category": "Storage",
                "name": "Internal SSD (NVMe)",
                "subsystem": "",
                "driver": "nvme (in-kernel)",
                "type": "storage",
                "options": [],
                "selected_option": 0,
                "packages_needed": [],
                "status_text": "Using in-kernel NVMe driver — no extra package required.",
            })

        # ---------------------------------------------------------- 5. Input
        if apple:
            devices.append({
                "category": "Input (Keyboard & Trackpad)",
                "name": "Apple Magic Keyboard / Trackpad",
                "subsystem": soc_name,
                "driver": "hid-apple (in-kernel)",
                "type": "input",
                "options": [],
                "selected_option": 0,
                "packages_needed": [],
                "status_text": "Using in-kernel hid-apple driver — no extra package required.",
            })

        return devices


class KoppieDriverManager(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Koppie Driver Manager (ARM)")
        self.geometry("780x620")
        self.minsize(700, 520)
        self.configure(fg_color=BG_DARK)

        self.devices = []
        self.option_vars = {}
        self.scanner = HardwareScanner()

        self.build_ui()
        self.scan_async()

    def build_ui(self):
        # HEADER BAR
        header = ctk.CTkFrame(self, fg_color=CARD_BG, corner_radius=0, height=75)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)

        # Koppie Logo
        if LOGO_PATH.exists():
            try:
                pil_img = Image.open(LOGO_PATH).resize((46, 46), Image.Resampling.LANCZOS)
                self.logo_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(46, 46))
                logo_lbl = ctk.CTkLabel(header, image=self.logo_img, text="")
                logo_lbl.pack(side="left", padx=(20, 14), pady=14)
            except Exception:
                pass

        title_box = ctk.CTkFrame(header, fg_color="transparent")
        title_box.pack(side="left", fill="y", pady=16)

        title = ctk.CTkLabel(
            title_box,
            text="Driver Manager  ·  ARM64",
            font=("Ubuntu", 18, "bold"),
            text_color=TEXT_PRIMARY
        )
        title.pack(anchor="w")

        subtitle = ctk.CTkLabel(
            title_box,
            text="Find and manage hardware drivers for your ARM computer",
            font=("Ubuntu", 12),
            text_color=TEXT_SECONDARY
        )
        subtitle.pack(anchor="w")

        # BOTTOM ACTION BAR
        self.footer = ctk.CTkFrame(self, fg_color=CARD_BG, corner_radius=0, height=60)
        self.footer.pack(fill="x", side="bottom")
        self.footer.pack_propagate(False)

        self.scan_btn = ctk.CTkButton(
            self.footer,
            text="Scan Again",
            font=("Ubuntu", 12, "bold"),
            fg_color="#333742",
            hover_color="#424755",
            text_color=TEXT_PRIMARY,
            height=36,
            width=110,
            corner_radius=6,
            command=self.scan_async
        )
        self.scan_btn.pack(side="left", padx=20, pady=12)

        self.net_lbl = ctk.CTkLabel(
            self.footer,
            text="● checking connection...",
            font=("Ubuntu", 12, "bold"),
            text_color=TEXT_SECONDARY
        )
        self.net_lbl.pack(side="left", padx=4, pady=12)

        self.apply_btn = ctk.CTkButton(
            self.footer,
            text="Apply Changes",
            font=("Ubuntu", 12, "bold"),
            fg_color=KOPPIE_CYAN,
            hover_color=KOPPIE_CYAN_HOVER,
            text_color="#000000",
            height=36,
            width=130,
            corner_radius=6,
            state="disabled",
            command=self.apply_changes
        )
        self.apply_btn.pack(side="right", padx=20, pady=12)

        # MAIN SCROLLABLE CONTENT
        self.content = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.content.pack(fill="both", expand=True, padx=20, pady=16)

        # System info badge
        self.info_lbl = ctk.CTkLabel(
            self.content,
            text="Detecting hardware configuration...",
            font=("Ubuntu", 12),
            text_color=TEXT_SECONDARY,
            anchor="w"
        )
        self.info_lbl.pack(fill="x", pady=(0, 12))

    def scan_async(self):
        self.scan_btn.configure(state="disabled", text="Scanning...")
        self.apply_btn.configure(state="disabled")

        for w in self.content.winfo_children():
            if w != self.info_lbl:
                w.destroy()

        threading.Thread(target=self._scan_worker, daemon=True).start()

    def _scan_worker(self):
        devices = self.scanner.detect_devices()
        model = self.scanner.get_system_model()
        kernel = self.scanner.get_kernel_version()
        arch = self.scanner.get_arch()
        online = self.scanner.is_online()
        apple = self.scanner.is_apple_silicon()
        _code, soc_name = self.scanner.get_soc()
        self.after(0, lambda: self._render_devices(devices, model, kernel, arch, soc_name, apple, online))

    def _render_devices(self, devices, model, kernel, arch, soc_name, apple, online=True):
        self.devices = devices
        self.online = online
        self.scan_btn.configure(state="normal", text="Scan Again")

        info = f"Computer: {model}  •  Kernel: {kernel}  •  Arch: {arch}"
        if apple and soc_name:
            info = f"Computer: {model}  •  SoC: {soc_name}  •  Kernel: {kernel}  •  Arch: {arch}"
        self.info_lbl.configure(text=info)

        if online:
            self.net_lbl.configure(text="● Online", text_color=SUCCESS_GREEN)
        else:
            self.net_lbl.configure(
                text="● Offline — connect to the internet to download drivers",
                text_color=WARNING_AMBER
            )

        has_actionable = False

        for idx, dev in enumerate(devices):
            card = ctk.CTkFrame(self.content, fg_color=CARD_BG, corner_radius=8)
            card.pack(fill="x", pady=6)

            # Card Header
            header_box = ctk.CTkFrame(card, fg_color="transparent")
            header_box.pack(fill="x", padx=16, pady=(12, 6))

            cat_lbl = ctk.CTkLabel(
                header_box,
                text=dev["category"].upper(),
                font=("Ubuntu", 10, "bold"),
                text_color=KOPPIE_CYAN
            )
            cat_lbl.pack(anchor="w")

            dev_name = ctk.CTkLabel(
                card,
                text=dev["name"],
                font=("Ubuntu", 13, "bold"),
                text_color=TEXT_PRIMARY,
                anchor="w",
                justify="left"
            )
            dev_name.pack(fill="x", padx=16, pady=(0, 6))

            if dev.get("driver") and dev["type"] != "storage":
                drv_lbl = ctk.CTkLabel(
                    card,
                    text=f"Driver in use: {dev['driver']}",
                    font=("Ubuntu", 11),
                    text_color=TEXT_SECONDARY,
                    anchor="w"
                )
                drv_lbl.pack(fill="x", padx=16, pady=(0, 4))

            # Options or Status
            if dev.get("options"):
                var = ctk.IntVar(value=dev["selected_option"])
                self.option_vars[idx] = var

                opt_box = ctk.CTkFrame(card, fg_color="transparent")
                opt_box.pack(fill="x", padx=16, pady=(0, 12))

                for o_idx, opt in enumerate(dev["options"]):
                    r_btn = ctk.CTkRadioButton(
                        opt_box,
                        text=f"{opt['title']}\n{opt['desc']}",
                        variable=var,
                        value=o_idx,
                        font=("Ubuntu", 12),
                        text_color=TEXT_PRIMARY,
                        fg_color=KOPPIE_CYAN,
                        command=self.on_selection_change
                    )
                    r_btn.pack(anchor="w", pady=4)

                if dev.get("packages_needed"):
                    has_actionable = True
            else:
                # Device already served by an in-tree driver
                status_box = ctk.CTkFrame(card, fg_color="#1d2824", corner_radius=6)
                status_box.pack(fill="x", padx=16, pady=(0, 12))

                status_txt = dev.get("status_text", "Using standard Linux driver.")
                st_lbl = ctk.CTkLabel(
                    status_box,
                    text=f"✓  {status_txt}",
                    font=("Ubuntu", 12),
                    text_color=SUCCESS_GREEN,
                    anchor="w",
                    justify="left"
                )
                st_lbl.pack(padx=12, pady=8, anchor="w")

        if not has_actionable:
            self.apply_btn.configure(state="disabled")

    def on_selection_change(self):
        # Enable Apply Changes if user selects an uninstalled driver
        needs_install = False
        for idx, dev in enumerate(self.devices):
            if idx in self.option_vars and dev.get("options"):
                chosen_idx = self.option_vars[idx].get()
                chosen_opt = dev["options"][chosen_idx]
                if not chosen_opt.get("installed") and chosen_opt.get("packages"):
                    needs_install = True

        self.apply_btn.configure(state="normal" if needs_install else "disabled")

    def apply_changes(self):
        if not getattr(self, "online", False):
            if not HardwareScanner.is_online():
                messagebox.showwarning(
                    "Offline",
                    "No internet connection.\nConnect to a network first, then press Scan Again."
                )
                return
            self.online = True

        packages_to_install = []
        for idx, dev in enumerate(self.devices):
            if idx in self.option_vars and dev.get("options"):
                chosen_idx = self.option_vars[idx].get()
                chosen_opt = dev["options"][chosen_idx]
                if not chosen_opt.get("installed") and chosen_opt.get("packages"):
                    packages_to_install.extend(chosen_opt["packages"])

        if not packages_to_install:
            return

        # Jangan sentuh pacman kalau lagi dipakai proses lain (update/install lain)
        if Path("/var/lib/pacman/db.lck").exists():
            messagebox.showwarning(
                "Package manager is busy",
                "Another program is using the package manager right now "
                "(an update or installation may already be running).\n\n"
                "Please wait a few minutes and try again."
            )
            return

        pkgs_str = " ".join(sorted(set(packages_to_install)))
        confirm = messagebox.askyesno(
            "Apply Changes",
            f"The following packages will be installed:\n\n{pkgs_str}\n\n"
            "Your system will also be updated in the same step, so the kernel and "
            "the driver headers always stay in sync.\n\n"
            "Do you want to continue?"
        )
        if not confirm:
            return

        self.apply_btn.configure(state="disabled", text="Installing...")
        self.scan_btn.configure(state="disabled")

        def _install_worker():
            # SATU transaksi: update sistem + headers + driver sekaligus.
            cmd = ["pkexec", "pacman", "-Syu", "--needed", "--noconfirm"] + packages_to_install
            proc = subprocess.run(cmd, capture_output=True, text=True)
            if proc.returncode == 0:
                self.after(0, lambda: messagebox.showinfo(
                    "Success",
                    "Drivers installed successfully!\n"
                    "Your system was updated in the same step, so the kernel and "
                    "the driver headers match.\n"
                    "A system restart may be required for changes to take effect."
                ))
            elif proc.returncode in (126, 127):
                # pkexec: 126/127 = dialog password ditutup / salah password
                self.after(0, lambda: messagebox.showinfo(
                    "Cancelled",
                    "Installation cancelled. Nothing was changed."
                ))
            else:
                self.after(0, lambda: messagebox.showerror(
                    "Error",
                    f"Failed to install driver.\n\n{proc.stderr or proc.stdout}"
                ))
            self.after(0, self.scan_async)

        threading.Thread(target=_install_worker, daemon=True).start()


if __name__ == "__main__":
    app = KoppieDriverManager()
    app.mainloop()
